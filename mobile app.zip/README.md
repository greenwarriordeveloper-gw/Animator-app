
  # mobile app

  This is a code bundle for mobile app. The original project is available at https://www.figma.com/design/P0vlt7B7hBSdMt6UygA1DS/mobile-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  