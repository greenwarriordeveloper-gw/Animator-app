Design a professional mobile attendance app for an Animator/Supervisor 
to manage daily worker attendance. Frame size: 390x844px (iPhone 14 Pro).
Clean white UI with deep blue and orange accent theme.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 1 — SPLASH SCREEN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- App name: "WorkTrack" centered with logo icon
- Tagline: "Attendance Made Simple"
- Loading bar at bottom
- Background: deep blue gradient #0F2540 → #1B3A6B

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 2 — ANIMATOR LOGIN SCREEN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Top: App logo + "Animator Login" heading
- Role badge: "ANIMATOR" pill tag in orange at top center
- Input fields:
  - Animator ID (e.g. ANM-00123) with ID card icon
  - Password with show/hide toggle
- "Remember Me" checkbox
- Login button: full width, deep blue
- Bottom note: "Only authorized animators can access this portal"
- All workers under this animator are auto-fetched after login
  based on their assigned Animator ID linkage

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 3 — ANIMATOR HOME DASHBOARD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOP HEADER:
- Left: "Hello, Ravi 👋" + Animator ID tag (ANM-00123)
- Right: Avatar + Notification bell
- Below: Today's date + Day (Saturday, 14 March 2026)
- Municipality label: "Chennai Municipal Zone 4"

ATTENDANCE TEAM CARD (Main Card — large, prominent):
- Card title: "Today's Attendance" with calendar icon
- 4 count boxes in a 2x2 grid inside the card:
  ┌──────────────┬──────────────┐
  │  👥 Total    │  ✅ Present  │
  │     48       │     32       │
  ├──────────────┼──────────────┤
  │  ❌ Absent   │  🕐 Not Taken│
  │     08       │     08       │
  └──────────────┴──────────────┘
- Each box: icon on top, big bold count, label below
- Color coding:
  Total = blue, Present = green, Absent = red, Not Taken = orange
- Below the grid: large CAMERA button
  - Rounded rectangle, orange background
  - Camera icon + "Mark Attendance" text
  - Subtitle: "Tap to capture & mark worker"
- Progress bar at bottom of card:
  "32 of 48 attendance completed" — green fill

RECENT ACTIVITY SECTION:
- Section header: "Recent Activity" + "View All" link
- Last 5 marked attendance entries as list cards:
  Each card contains:
  - Worker photo (small circle avatar, 40x40)
  - Worker Name + Employee ID
  - Check-in time
  - Status badge: Present / Absent / Late
  - Municipality tag in small grey pill
- Horizontal swipe on each card to Undo or Edit

BOTTOM SUMMARY BAR (sticky above nav):
- "Total Marked Today: 32 / 48"
- "Submit Attendance" button (full width, deep blue)

BOTTOM NAVIGATION:
- 4 tabs: Home | Workers | Reports | Profile
- Active tab: orange underline + filled icon

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 4 — CAMERA / MARK ATTENDANCE SCREEN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Full screen camera view
- Top bar: Back arrow + "Mark Attendance" title
- Center: Rectangular face frame with corner brackets (animated)
- Below camera: Worker info auto-populated after scan:
  - Worker photo pulled from database
  - Name: Suresh Kumar
  - Emp ID: EMP-00456
  - Municipality: Zone 4, Chennai
  - Cost/Rate: ₹650/day
- Status selector buttons (3 options):
  [✅ Present]  [❌ Absent]  [⏰ Half Day]
- "Confirm & Save" button — orange, full width
- Manual Search option: "Search Worker by ID" link below

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 5 — WORKER LIST SCREEN
(All workers tagged to this Animator's ID)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Header: "My Workers (48)" + search bar + filter icon
- Filter chips: All | Present | Absent | Not Taken | Half Day
- Worker list (scrollable):
  Each worker card:
  ┌─────────────────────────────────┐
  │ [Photo] Name: Suresh Kumar      │
  │         ID: EMP-00456           │
  │         Municipality: Zone 4    │
  │         Cost: ₹650/day          │
  │         Status: [Not Taken 🕐]  │
  │         [Mark Now] button       │
  └─────────────────────────────────┘
- Workers with "Not Taken" status shown at top
- Completed workers show green tick on card
- Sticky header showing: Pending: 8 | Done: 40

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 6 — SUBMISSION CONFIRMATION SCREEN
(After animator taps "Submit Attendance")
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Header: "Submission Summary"
- Date: Saturday, 14 March 2026
- Animator: Ravi Kumar (ANM-00123)
- Summary card:
  - Total Workers: 48
  - Punch Completed: 40 ✅
  - Punch Pending: 8 ⚠️
- Warning banner (if pending > 0):
  "⚠️ 8 workers attendance not completed. Submit anyway?"
- PENDING WORKERS LIST (collapsible):
  Each row: Photo | Name | ID | Municipality
  With a "Mark Now" quick action button on each row
- Two action buttons at bottom:
  [Go Back & Complete]  [Submit Anyway]
- After final submit: success animation
  "✅ Attendance Submitted Successfully"
  + "Generate Report" button

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 7 — PUNCH COMPLETED CHECK SCREEN
(Who has completed punch / who hasn't)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Header: "Punch Status — 14 Mar 2026"
- Toggle tabs: [Completed ✅ (40)] [Pending ⏳ (8)]
- COMPLETED TAB:
  List of workers with completed punch:
  Each row:
  - Circular photo
  - Name + Employee ID
  - Check-in time
  - Status: Present / Half Day / Absent
  - Green checkmark icon on right
- PENDING TAB:
  List of workers with no punch:
  Each row:
  - Greyed out photo with "?" overlay
  - Name + Employee ID
  - "Not Marked" red label
  - "Mark Now" orange button on right
- Search bar at top to find specific worker
- Export icon (top right) to export this list

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 8 — DAILY REPORT SCREEN
(Day-wise attendance report with PDF export)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Header: "Attendance Report" + Export PDF icon (top right)
- Date selector: calendar picker (single day or range)
- Selected: 14 March 2026
- Municipality filter dropdown: All Zones | Zone 1 | Zone 2...
- Summary row (horizontal):
  Total: 48 | Present: 32 | Absent: 8 | Half Day: 8

- REPORT TABLE (scrollable, card style):
  Each worker row card:
  ┌─────────────────────────────────────┐
  │ [Photo]  Name: Suresh Kumar         │
  │          Emp ID: EMP-00456          │
  │          Cost: ₹650/day             │
  │          Municipality: Zone 4       │
  │          Status: ✅ Present         │
  │          Check-in: 08:45 AM         │
  └─────────────────────────────────────┘
  - Photo is circular, 48x48px
  - Status badge color coded
  - Cost shown per day

- EXPORT PDF BUTTON:
  - Large full width button at bottom
  - "📄 Export as PDF" — deep blue
  - Secondary: "📊 Export as Excel" — outlined button
  - PDF includes: Date, Animator Name, 
    Municipality, and full table with photos

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN 9 — PDF REPORT PREVIEW SCREEN
(Preview before downloading)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Simulated A4 paper card preview on screen
- PDF Header section:
  - Company logo (top left)
  - Report Title: "Daily Attendance Report"
  - Date: 14 March 2026
  - Animator: Ravi Kumar | ID: ANM-00123
  - Municipality: Chennai Zone 4
- Table inside preview:
  Columns: # | Photo | Emp ID | Name | Cost | Municipality | Status
  Rows: each worker with small photo thumbnail
- Footer: Total Present | Absent | Cost Summary
- Bottom buttons:
  [⬇️ Download PDF]  [📤 Share]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DESIGN SYSTEM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Frame: 390 x 844px
- Font: Plus Jakarta Sans
- Primary: #0F2540 (deep blue)
- Accent: #F97316 (orange)
- Success: #22C55E (green)
- Error: #EF4444 (red)
- Warning: #F59E0B (amber)
- Background: #F8FAFC
- Card radius: 16px
- Button radius: 12px
- Shadow: 0px 4px 16px rgba(0,0,0,0.08)
- Safe area: 44px top, 34px bottom
- 8px base grid spacing
- Auto Layout on all components
- Outline icons: 24x24px (Lucide style)
- All interactive states: default, pressed, disabled
- Light mode + dark mode variants