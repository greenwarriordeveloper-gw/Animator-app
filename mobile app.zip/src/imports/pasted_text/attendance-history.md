Add Attendance History screens to the existing app with 
two modes: Individual History and Bulk History.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN — ATTENDANCE HISTORY HOME
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Header: "Attendance History" with back arrow
- Two large mode selector cards:

  ┌─────────────────────────────┐
  │  👤 Individual History      │
  │  View single worker's       │
  │  complete attendance log    │
  │  → Tap to open              │
  └─────────────────────────────┘

  ┌─────────────────────────────┐
  │  👥 Bulk History            │
  │  View all workers by        │
  │  date range or zone         │
  │  → Tap to open              │
  └─────────────────────────────┘

- Quick filter chips below:
  Today | This Week | This Month | Custom Range

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN — INDIVIDUAL HISTORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOP SEARCH SECTION:
- Search bar: "Search by Name or Employee ID"
- Recent searches chips: 
  EMP-00456 | EMP-00457 | EMP-00458

WORKER PROFILE CARD (appears after search):
┌──────────────────────────────────┐
│  [Photo]  Suresh Kumar           │
│           EMP-00456              │
│           Zone 4 · Chennai       │
│           Cost: ₹650/day         │
│                                  │
│  📊 This Month Summary:          │
│  ✅ Present: 18  ❌ Absent: 3    │
│  ⏰ Half Day: 2  🏖 Leave: 1     │
│  💰 Total Earned: ₹12,350        │
└──────────────────────────────────┘

DATE FILTER ROW:
- Month picker dropdown
- Year picker dropdown  
- "Custom Range" button

ATTENDANCE LOG (scrollable list):
Each day row:
┌──────────────────────────────────┐
│ 📅 Mon, 14 Mar 2026              │
│ In: 08:45 AM  Out: 05:30 PM     │
│ Hours: 8.45 hrs                  │
│ Status: ✅ Present               │
│ Cost: ₹650   Zone 4             │
└──────────────────────────────────┘

Status color coding per row:
- Present → green left border
- Absent → red left border  
- Half Day → orange left border
- Leave → blue left border
- Not Marked → grey left border

MONTHLY CALENDAR VIEW (toggle):
- Small calendar showing color dots per day
- Green dot = Present
- Red dot = Absent
- Orange dot = Half Day
- Grey dot = Not Marked
- Tap any date → shows that day detail popup

BOTTOM ACTION BAR:
- [📄 Export Individual PDF]
- [📊 Export Excel]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN — INDIVIDUAL DAY DETAIL POPUP
(appears when tapping a date)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Bottom sheet modal (slides up)
- Worker photo + name + ID
- Date: Monday, 14 March 2026
- Details:
  - Check-in Time: 08:45 AM
  - Check-out Time: 05:30 PM
  - Total Hours: 8 hrs 45 mins
  - Status: Present
  - Marked By: Animator Ravi (ANM-00123)
  - Location: Zone 4, Chennai
  - Cost Applied: ₹650
  - Photo captured: small thumbnail
- Edit button (for corrections)
- Close button

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN — BULK HISTORY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOP FILTER SECTION:
- Date Range: [Start Date] → [End Date]
- Zone/Municipality dropdown: All Zones | Zone 1 | Zone 2...
- Status filter chips: 
  All | Present | Absent | Half Day | Not Marked
- Search by worker name/ID bar
- "Apply Filter" button — orange

SUMMARY BANNER (updates based on filter):
┌──────────────────────────────────┐
│ 14 Mar – 21 Mar 2026 · All Zones │
│ Workers: 48 · Days: 7            │
│ Total Records: 336               │
│ Present: 224 | Absent: 56        │
│ Half Day: 36 | Not Marked: 20    │
└──────────────────────────────────┘

VIEW TOGGLE (top right):
[👤 By Worker]  [📅 By Date]

--- BY WORKER VIEW ---
Each worker expandable card:
┌──────────────────────────────────┐
│ [Photo] Suresh Kumar  EMP-00456  │
│ Zone 4 · ₹650/day               │
│ ✅18  ❌3  ⏰2  🏖1              │
│ Total: ₹12,350  ▼ expand        │
└──────────────────────────────────┘
Expand → shows day by day log:
  14 Mar → Present → ₹650
  13 Mar → Present → ₹650
  12 Mar → Absent  → ₹0
  11 Mar → Half Day → ₹325

--- BY DATE VIEW ---
Each date expandable card:
┌──────────────────────────────────┐
│ 📅 Saturday, 14 March 2026       │
│ Total: 48 | Present: 32 | Abs: 8 │
│ Half Day: 2 | Not Marked: 6  ▼  │
└──────────────────────────────────┘
Expand → shows all workers for that day:
  Suresh Kumar → Present → 08:45 AM
  Murugan P → Present → 08:52 AM
  Rajesh M → Absent
  Kavitha S → Not Marked

BULK SELECTION (for export):
- "Select All" checkbox at top
- Each card has a checkbox
- Bottom bar appears when selected:
  "12 selected → [Export PDF] [Export Excel]"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SCREEN — BULK HISTORY PDF PREVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- A4 preview card
- Report header:
  Company Logo | "Bulk Attendance Report"
  Date Range: 14 Mar – 21 Mar 2026
  Zone: All Zones
  Animator: Ravi Kumar | ANM-00123

- Table columns:
  # | Photo | Emp ID | Name | 
  Municipality | 14/3 | 15/3 | 16/3... 
  | Total Days | Total Cost

- Each date cell: P / A / H / - 
  (Present / Absent / Half / Not Marked)
  Color coded cells

- Grand Total row at bottom:
  Total Cost: ₹2,45,800

- Download + Share buttons

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
UPDATED BOTTOM NAVIGATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Add History tab to bottom nav:
Home | Workers | History | Reports | Profile
                  ↑
           (new tab added)
           Clock icon